Quick info about the fusion 360 3D files.
